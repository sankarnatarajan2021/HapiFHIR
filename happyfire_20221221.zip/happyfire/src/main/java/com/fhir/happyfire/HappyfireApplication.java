package com.fhir.happyfire;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;



@SpringBootApplication
public class HappyfireApplication {

	public static void main(String[] args) {
		SpringApplication.run(HappyfireApplication.class, args);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Bean
	public org.springframework.boot.web.servlet.ServletRegistrationBean ServletRegistrationBean(){
		
	     org.springframework.boot.web.servlet.ServletRegistrationBean registration=new org.springframework.boot.web.servlet.ServletRegistrationBean(new HomeRestfulServer(),"/*");
	     registration.setName("FhirServlet");
	      return registration;
	
	}

}
