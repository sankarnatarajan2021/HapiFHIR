package com.fhir.happyfire;

import javax.servlet.ServletException;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.server.RestfulServer;

import javax.servlet.annotation.WebServlet;

@WebServlet("/*")
public class HomeRestfulServer extends RestfulServer{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	//Initialize
	@Override
	protected void initialize()throws ServletException{
		//create a context for the appropriate version
		setFhirContext(FhirContext.forR4());
		
		//Registerresourceproviders
		registerProvider(new PatientResourceProvider());
	}
}
